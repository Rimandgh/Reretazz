package objects

type CertResponse struct {
	Id      string `json:"id"`
	Message string `json:"message"`
	Status  string `json:"status"`
}
